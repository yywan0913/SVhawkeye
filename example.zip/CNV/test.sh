../../hawkeye.py regiondepth_browse -i HG002_GRCh38.haplotag.10x.chr2_226468627-226471765.bam -o cnvout/ -r chr2:226468627-226471765 -F png
#../../hawkeye.py regiondepth_browse -i /mnt/e/usr/xiaoyh/HG002/HG002_GRCh38.haplotag.10x.bam -o cnvout/ -r chr2:226468627-226471765 -F png
