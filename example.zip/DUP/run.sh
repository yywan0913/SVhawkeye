# ../../hawkeye.py sv_browse -i /mnt/e/usr/xiaoyh/HG002/HG002_GRCh38.haplotag.10x.bam -b test.bed  -f bed -t 4 -o outdir/
../../hawkeye.py sv_browse -i HG002_GRCh38.haplotag.10x.dup.bam -b test.bed  -f bed -t 4 -o outdir/ -F pdf
