../../hawkeye.py sv_browse -i  SRR9982132.minimap2.sorted.bam  -b input.bed -g hg19 -t 2 -o outdir
../../hawkeye.py sv_genotyping -i  SRR9982132.minimap2.sorted.bam  -b tra.vcf -f vcf -o genotyping -t 2
