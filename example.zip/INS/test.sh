#../../hawkeye.py sv_browse -i /mnt/e/usr/xiaoyh/HG002/HG002_GRCh38.haplotag.10x.bam -b test.ins.vcf  -f vcf -t 4 -o outdir/ -g hg38 -F pdf
../../hawkeye.py sv_browse -i HG002_GRCh38.haplotag.10x.pbsv.INS.1101.bam -b test.ins.vcf  -f vcf -t 4 -o outdir/ -g hg38 -F pdf
