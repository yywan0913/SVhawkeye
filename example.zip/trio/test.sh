### bam files are too big ， they were deleted by auto
 ../../hawkeye.py snpindel_browse -i bam/HG002.bam,bam/HG003.bam,bam/HG004.bam -b HG002_TRIO_10.input.test.vcf -f vcf -g hg38 -r /mnt/e/linux/database/genome/human/hg38/GRCh38.p13.genome.fa -o out
