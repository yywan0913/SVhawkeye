 ../../hawkeye.py sv_browse -i HG002_GRCh38.haplotag.10x.inv.bam -b inv.vcf  -f vcf -t 4 -o outdir -g hg38
 ../../hawkeye.py sv_genotyping  -i HG002_GRCh38.haplotag.10x.inv.bam -b inv.vcf -f vcf -t 4 -o genotyping/
