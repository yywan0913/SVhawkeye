 #../../hawkeye.py sv_browse -i /mnt/e/usr/xiaoyh/HG002/HG002_GRCh38.haplotag.10x.bam -b test.del.vcf  -f vcf -t 4 -o outdir/ -g hg38 -F pdf

# ../../hawkeye.py sv_genotyping -i /mnt/e/usr/xiaoyh/HG002/HG002_GRCh38.haplotag.10x.bam -b test.del.vcf -f vcf -t 4 -o genotype_test

 ../../hawkeye.py sv_browse -i HG002_GRCh38.haplotag.10x.del_test.bam -b test.del.vcf  -f vcf -t 4 -o outdir/ -g hg38 -F pdf

  ../../hawkeye.py sv_genotyping -i HG002_GRCh38.haplotag.10x.del_test.bam -b test.del.vcf -f vcf -t 4 -o genotype_test
