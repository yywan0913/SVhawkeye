../../hawkeye.py rna_browse -i samtools index NA12878-DirectRNA.pass.dedup.NoU.fastq.hg38.minimap2.sorted.test.bam -b input.bed -g hg38 -t 3 -o outdir
# or
../../hawkeye.py rna_browse -i samtools index NA12878-DirectRNA.pass.dedup.NoU.fastq.hg38.minimap2.sorted.test.bam -b input.bed -g hg38 -t 3 -o outdir -p ../../database/hg38/hg38.genePred.gz
